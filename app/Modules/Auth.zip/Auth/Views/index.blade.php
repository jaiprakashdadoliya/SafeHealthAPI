<?php

echo trans('Auth::example.welcome');