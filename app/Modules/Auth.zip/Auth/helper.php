<?php

/**
 *	Auth Helper  
 */